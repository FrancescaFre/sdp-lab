package simulation_src_2019;

public interface Buffer {

    void addMeasurement(Measurement m);

}
