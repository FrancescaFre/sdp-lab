/*
import static org.junit.Assert.assertEquals;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import serverREST.AdminCli;

public class TestClient {
@Test
   public void test1()
    {
        AdminCli admin = new AdminCli();
        assertEquals("primo test" 200, admin.);
    }

}*/
